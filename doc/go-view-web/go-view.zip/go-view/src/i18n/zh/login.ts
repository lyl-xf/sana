export default {
  desc: "登录",
  form_auto: "自动登录",
  form_button: "登录",
  login_message: "请填写完整信息",
  login_success: "登录成功！",
}