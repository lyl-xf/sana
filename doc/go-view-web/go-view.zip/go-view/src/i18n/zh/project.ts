export default {
  // aside
  create_btn: '新建',
  create_success: '新建成功！',
  create_failure: '新建失败，请稍后重试！',
  create_tip: '从哪里出发好呢？',
  project: '项目',
  my: '我的',
  new_project: '新项目',
  all_project: '全部项目',
  my_template: '我的模板',
  template_market: '模板市场',

  // items 
  release: '已发布',
  unreleased: '未发布',
  last_edit: '最后编辑'
}
