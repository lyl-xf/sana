export default {
  create_btn: 'Creat',
  create_success: 'Creat Success!',
  create_failure: 'Failed to create, please try again later！',
  create_tip: 'Please select a content for development!',
  project: 'Project',
  my: 'My',
  new_project: 'New Project',
  all_project: 'All Project',
  my_template: 'My Template',
  template_market: 'Template Market',

  // items 
  release: 'Release',
  unreleased: 'Unrelease',
  last_edit: 'Last edit time'
}
