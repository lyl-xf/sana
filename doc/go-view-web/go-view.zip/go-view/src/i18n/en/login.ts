export default {
  desc: "Login",
  form_auto: "Sign in automatically",
  form_button: "Login",
  login_success: "Login success!",
  login_message: "Please complete the letter!",
}