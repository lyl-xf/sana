export enum DialogEnum {
  DELETE = 'delete',
  WARNING = 'warning',
  ERROR = 'error',
  SUCCESS = 'success'
}
