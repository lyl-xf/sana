import { MapBaseConfig } from './MapBase/index'
import { MapAmapConfig } from './MapAmap/index'

export default [MapBaseConfig, MapAmapConfig]
