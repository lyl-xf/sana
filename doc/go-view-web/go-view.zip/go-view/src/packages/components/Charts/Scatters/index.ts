import { ScatterCommonConfig } from './ScatterCommon/index'
import { ScatterLogarithmicRegressionConfig } from './ScatterLogarithmicRegression/index'

export default [ScatterCommonConfig, ScatterLogarithmicRegressionConfig]
