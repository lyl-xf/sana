import { PieCommonConfig } from './PieCommon/index'
import { PieCircleConfig } from './PieCircle/index'

export default [PieCommonConfig, PieCircleConfig]