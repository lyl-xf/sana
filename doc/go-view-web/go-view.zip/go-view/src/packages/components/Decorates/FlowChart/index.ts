import { FlowChartLineConfig } from './FlowChartLine/index'

export default [FlowChartLineConfig]
