import { Decorates01Config } from './Decorates01/index'
import { Decorates02Config } from './Decorates02/index'
import { Decorates03Config } from './Decorates03/index'
import { Decorates04Config } from './Decorates04/index'
import { Decorates05Config } from './Decorates05/index'
import { Decorates06Config } from './Decorates06/index'

export default [
  Decorates01Config,
  Decorates02Config,
  Decorates03Config,
  Decorates04Config,
  Decorates05Config,
  Decorates06Config
]
