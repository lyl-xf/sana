import { Border01Config } from './Border01/index'
import { Border02Config } from './Border02/index'
import { Border03Config } from './Border03/index'
import { Border04Config } from './Border04/index'
import { Border05Config } from './Border05/index'
import { Border06Config } from './Border06/index'
import { Border07Config } from './Border07/index'
import { Border08Config } from './Border08/index'
import { Border09Config } from './Border09/index'
import { Border10Config } from './Border10/index'
import { Border11Config } from './Border11/index'
import { Border12Config } from './Border12/index'
import { Border13Config } from './Border13/index'

export default [
  Border01Config,
  Border02Config,
  Border03Config,
  Border04Config,
  Border05Config,
  Border06Config,
  Border07Config,
  Border08Config,
  Border09Config,
  Border10Config,
  Border11Config,
  Border12Config,
  Border13Config
]
