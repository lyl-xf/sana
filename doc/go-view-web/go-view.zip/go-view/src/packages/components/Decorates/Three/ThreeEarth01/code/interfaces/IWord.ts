export interface IWord {
  dom: HTMLElement
  data: any
  width: number
  height: number
}