
export interface IEvents {
  resize: () => void
}
