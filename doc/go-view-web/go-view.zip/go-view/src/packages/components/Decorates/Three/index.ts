import { ThreeEarth01Config } from './ThreeEarth01/index'

export default [ThreeEarth01Config]
