import MaterialLine from './MaterialLine'
import Common from './Common'
import Weather from './Weather'

export const IconList = [...MaterialLine, ...Weather, ...Common]
