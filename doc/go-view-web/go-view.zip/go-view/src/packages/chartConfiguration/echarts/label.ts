export const labelConfig = {
  position: [
    { label: '外侧', value: 'outside' },
    { label: '内部', value: 'inside' },
    { label: '中心', value: 'center' }
  ],
  fontWeight: [
    { label: '正常', value: 'normal' },
    { label: '普通加粗', value: 'bold' },
    { label: '加粗', value: 'bolder' },
    { label: '细体', value: 'lighter' }
  ]
}
