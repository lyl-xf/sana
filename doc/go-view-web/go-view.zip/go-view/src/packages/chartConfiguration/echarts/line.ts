export const lineConf = {
  lineStyle: {
    type: [
      {
        label: 'solid',
        value: 'solid'
      },
      {
        label: 'dashed',
        value: 'dashed'
      },
      {
        label: 'dotted',
        value: 'dotted'
      }
    ]
  }
}
