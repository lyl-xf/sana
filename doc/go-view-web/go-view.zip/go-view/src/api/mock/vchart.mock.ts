import bar from './vchart/bar.json'

export default {
  bar: {
    code: 0,
    status: 200,
    msg: '请求成功',
    data: bar
  }
}
