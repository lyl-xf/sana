<template>
  <layout-main></layout-main>
</template>

<script lang="ts" setup>
import { LayoutMain } from '@/layout/components/LayoutMain/index'
</script>