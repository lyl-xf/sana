import LayoutMain from './index.vue';

export { LayoutMain };
