import LayoutTransitionMain from './index.vue';

export { LayoutTransitionMain };
