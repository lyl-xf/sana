import LayoutFooter from './index.vue'

export { LayoutFooter }