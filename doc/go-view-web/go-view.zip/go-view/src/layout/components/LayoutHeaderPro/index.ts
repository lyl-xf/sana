import LayoutHeaderPro from './index.vue'

export { LayoutHeaderPro }