import GoUserInfo from './index.vue';

export { GoUserInfo };
