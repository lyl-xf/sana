import GoReload from './index.vue';

export { GoReload };
