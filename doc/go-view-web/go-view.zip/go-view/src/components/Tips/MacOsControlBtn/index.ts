import MacOsControlBtn from './index.vue';

export { MacOsControlBtn };
