import I18n from './index.vue';

export { I18n };
