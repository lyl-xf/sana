<template>
  <div>
    <!-- 骨架图 -->
     <go-skeleton :repeat="3" :show="true"></go-skeleton>
  </div>
</template>