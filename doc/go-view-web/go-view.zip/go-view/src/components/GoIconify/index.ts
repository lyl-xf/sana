import GoIconify from './index.vue';

export { GoIconify };
