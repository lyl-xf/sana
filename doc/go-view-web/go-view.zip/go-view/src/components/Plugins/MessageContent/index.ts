import MessageContent from './index.vue';

export { MessageContent };
