import DialogContent from './index.vue';

export { DialogContent };
