import LoadingContent from './index.vue';

export { LoadingContent };
