import GoLangSelect from './index.vue';

export { GoLangSelect };
