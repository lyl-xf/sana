import ThemeColorSelect from './index.vue';

export { ThemeColorSelect };
