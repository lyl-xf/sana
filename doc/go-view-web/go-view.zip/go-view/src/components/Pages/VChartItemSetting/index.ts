import VChartGlobalSetting from './VChartGlobalSetting.vue'
import Axis from './Axis.vue'
import Label from './Label.vue'
import Bar from './Bar.vue'
import Line from './Line.vue'
import Point from './Point.vue'

export { VChartGlobalSetting, Axis, Label, Bar, Line, Point }
