import MonacoEditor from './index.vue';
import EditorWorker from './EditorWorker.vue';

export { MonacoEditor, EditorWorker };
