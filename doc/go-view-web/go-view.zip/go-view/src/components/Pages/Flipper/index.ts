import Flipper from './index.vue'

type FlipType = 'up' | 'down'

export { Flipper, FlipType }
