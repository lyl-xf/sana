import ChartGlobImage from './index.vue'

export { ChartGlobImage }
