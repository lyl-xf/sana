import GoVChart from './index.vue'

export { GoVChart }