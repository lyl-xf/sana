import GoSystemSet from './index.vue';

export { GoSystemSet };
