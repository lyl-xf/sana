import GoSkeleton from './index.vue';

export { GoSkeleton };
