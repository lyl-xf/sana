import GoSystemInfo from './index.vue';

export { GoSystemInfo };
