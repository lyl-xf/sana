import GoAppProvider from './index.vue';

export { GoAppProvider };
