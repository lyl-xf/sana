import GoThemeSelect from './index.vue';

export { GoThemeSelect };
